import pandas as pd
import numpy as np
from surprise import SVD

print("Environment setup successful!")
