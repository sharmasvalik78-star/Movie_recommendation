import requests
import pandas as pd
import time

API_KEY = "2b6915d50fc8b583807848395532c416"
BASE_URL = "https://api.themoviedb.org/3"

movies = []

session = requests.Session()

for page in range(1, 21):  # 🔥 reduce to 20 pages (~400 movies)
    try:
        url = f"{BASE_URL}/discover/movie"
        params = {
            "api_key": API_KEY,
            "sort_by": "popularity.desc",
            "page": page
        }

        response = session.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        for m in data.get("results", []):
            movies.append({
                "tmdbId": m["id"],
                "title": m["title"],
                "overview": m.get("overview", ""),
                "genre_ids": " ".join(map(str, m.get("genre_ids", []))),
                "rating": m.get("vote_average", 0),
                "popularity": m.get("popularity", 0)
            })

        print(f"Page {page} collected")
        time.sleep(1)  # ✅ important: slow down requests

    except Exception as e:
        print(f"Skipping page {page} due to error: {e}")
        time.sleep(2)

df = pd.DataFrame(movies)

if not df.empty:
    df.to_csv("artifacts/tmdb_movies.csv", index=False)
    print("TMDB dataset created successfully!")
else:
    print("No data collected.")
